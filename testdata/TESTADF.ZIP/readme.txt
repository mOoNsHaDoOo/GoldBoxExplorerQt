Synthetic archive for GoldBoxExplorerQt.
